public class SistemaSufragio {

    private Sufragio s;

    private Object untitledField;

    public void untitledMethod() {
    }
}
