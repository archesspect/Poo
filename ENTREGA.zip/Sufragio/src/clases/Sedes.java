package clases;
import colecciones.ColeccionVotantes;
import colecciones.ColeccionVocales;

public class Sedes {
	private String nombre;
	private String ubicacion;
	private String capacidadLocal;
	private int capacidadDeLocal;
	private ColeccionVotantes votantes;
	private ColeccionVocales vocales;//anidacion votantes dentro de sedes
	
	public Sedes(String nombre, String ubicacion, String capacidadLocal){
		this.nombre = nombre;
		this.ubicacion = ubicacion;
		this.capacidadLocal = capacidadLocal;
		votantes = new ColeccionVotantes();
		vocales = new ColeccionVocales();
	}
	
	// SOBRECARGA
	public void modificarCapacidad(String capacidadLocal) {
		this.capacidadLocal = capacidadLocal;
	}
	
	public void modificarCapacidad(int capacidadDeLocal) {
		this.capacidadDeLocal = capacidadDeLocal;
	}
	
	//LLamado a metodos
	
	public boolean agregarVotante (Votantes v){
		return votantes.a�adirVotantes(v);
	}
	
	public boolean eliminarVotante(Votantes ev) {
		return votantes.eliminarVotantes(ev);
		
	}
	
	public boolean a�adirVocales (Vocal av){
		return vocales.a�adirVocales(av);
	}
	
	public boolean eliminarVocales(Vocal ev) {
		return vocales.eliminarVocales(ev);
	}
	
	//Getter & Setters
	
	public int getcapacidadDeLocal(int capacidad) {
		return capacidadDeLocal;
	}

	public void setcapacidadDeLocal(int capacidad) {
		this.capacidadDeLocal = capacidad;
	}
	
	
	public String getnombre() {
		return nombre;
	}
	public void setnombre(String nombre) {
		this.nombre = nombre;
	}
	
	public String getcapacidadLocal() {
		return capacidadLocal;
	}
	public void setcapacidadLocal(String capacidadLocal) {
		this.capacidadLocal = capacidadLocal;
	}
	
	public String getubicacion() {
		return ubicacion;
	}
	public void setubicacion(String ubicacion) {
		this.ubicacion = ubicacion;
	}


	
}
