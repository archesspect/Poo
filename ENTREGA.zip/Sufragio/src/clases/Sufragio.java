package clases;

import colecciones.ColeccionSedes;

public class Sufragio{
	private ColeccionSedes sedes;
	
	public Sufragio() {
		sedes = new ColeccionSedes();
	}
	
	public boolean a�adirSedes (Sedes nombre, Sedes ubicacion, Sedes capacidadLocal  ) {
		return a�adirSedes(nombre, ubicacion, capacidadLocal);
	}
	
	public void mostrarSedes() {
		sedes.mostrarSedes();
	}
	
	public boolean eliminarSedes(String nombreSede) {
		return sedes.eliminarSede(nombreSede);
	}
	
	public boolean a�adirVotante(String nombreSede, Votantes votante) {
		return sedes.a�adirVotante(nombreSede, votante);
	}
	
	public void mostrarVotantes() {
		sedes.mostrarVotantes();
	}
	
	public boolean eliminarVotantes(String eliminarVotante) {
		return sedes.eliminarVotantes(eliminarVotante);
	}
	
	public boolean a�adirVocal(String nombreSede, Vocal v){
		return sedes.a�adirVocales(nombreSede, v);
	}
	
	public void mostrarVocales() {
		sedes.mostrarVocales();
	}
	
	public boolean eliminarVocales(String eliminarVocal) {
		return false;
	}
	
	

}
