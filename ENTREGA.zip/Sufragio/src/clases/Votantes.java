package clases;
import colecciones.ColeccionVocales;

public class Votantes {
	
	private String nombreVotante;
	private String ubicacionVotante;
	private String identificadorVotante;
	private ColeccionVocales vocales; // Anidaci�n a vocales de mesa
	private int identificador;
	
	
	public Votantes(String nombreVotante,String ubicacionVotante,String identificadorVotante) {
		this.nombreVotante = nombreVotante;
		this.ubicacionVotante = ubicacionVotante;
		this.identificadorVotante = identificadorVotante;
		vocales = new ColeccionVocales();

	}
	
	//SOBRECARGA
	public void modificarIdentificador(String identificadorVotante) {
		this.identificadorVotante = identificadorVotante;
	}
	public void modificarIdentificador(int identificador){
		this.identificador = identificador;
	}
	
	//LLamado a metodos
	public boolean agregarVocal (Vocal v){
		return vocales.a�adirVocales(v);
	}
	
	public boolean eliminarVocal(Vocal ev) {
		return vocales.eliminarVocales(ev);
	}
	
	//Getters & Setters
	public int getidentificador() {
		return identificador;
	}
	
	public void setidentificador(int rut) {
		this.identificador = rut;
	}
	
	public String getnombreVotante() {
		return nombreVotante;
	}
	public void setnombreVotante(String nombreVotante) {
		this.nombreVotante = nombreVotante;
	}
	
	public String getubicacionVotante() {
		return ubicacionVotante;
	}
	public void setubicacionVotante(String ubicacionVotante) {
		this.ubicacionVotante = ubicacionVotante;
	}
	
	public String getidentificadorVotante() {
		return identificadorVotante;
	}
	public void setidentificadorVotante(String identificadorVotante) {
		this.identificadorVotante = identificadorVotante;
	}

}
