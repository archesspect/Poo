package clases;
public class Vocal {
	
	private String nombreVocal;
	private String identificadorVocal;
	private String ubicacionVocal;
	
	public Vocal(String nombreVocal, String identificadorVocal, String ubicacionVocal){
		this.nombreVocal = nombreVocal;
		this.identificadorVocal = identificadorVocal;
		this.ubicacionVocal = ubicacionVocal;
	}

	public String getNombreVocal() {
		return nombreVocal;
	}
	
	public void setNombreVocal(String nombreVocal) {
		this.nombreVocal = nombreVocal;
	}
	
	public String getIdentificadorVocal() {
		return identificadorVocal;
	}
	
	public void setIdentificadorVocal(String identificadorVocal) {
		this.identificadorVocal = identificadorVocal;
	}
	
	public String getUbicacionVocal() {
		return ubicacionVocal;
	}
	
	public void setUbicacionVocal(String ubicacionVocal) {
		this.ubicacionVocal = ubicacionVocal;
	}

	public String ubicacionVotante() {
		// TODO Auto-generated method stub
		return null;
	}

}
