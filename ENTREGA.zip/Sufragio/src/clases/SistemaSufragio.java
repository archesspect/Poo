package clases;

import java.util.InputMismatchException;
import java.util.Scanner;

public class SistemaSufragio {

	public static void main(String[] args) {
		
		Scanner sn = new Scanner(System.in);
		boolean salir = false;
		int opcion;
		int opcion1 = 0;
		int opcion2 = 0;
		int opcion3 = 0;
		Sufragio sufragio = new Sufragio();
		
		while(!salir) {
			
			System.out.println("Ingrese un numero del 1-4");
			System.out.println("1.- A�adir Elemento");
			System.out.println("2.- Modificar Elemento");
			System.out.println("3.- Eliminar Elemento");
			System.out.println("4.- Buscar Elemento");
			salir = true;
		}
		
		try {
			opcion = sn.nextInt();
			
			String nombreSede = null;
			switch (opcion) {
				case 1:
						System.out.println("� Que deseas a�adir ?");
						System.out.println("1.- A�adir Sede de votaci�n");
						System.out.println("2.- A�adir votante");
						System.out.println("3.- A�adir vocal de mesa");
						System.out.println("4.- Presione 4 para salir");
						opcion = sn.nextInt();
					
					switch(opcion) {
						case 1:
							System.out.println("Has seleccionado la opcion 1");
							System.out.println("Porfavor Ingresar nombre de la sede");
							break;
						case 2:
							System.out.println("Has seleccionado la opcion 2");
							break;
						case 3:
							System.out.println("Has seleccionado la opcion 3");
							break;
						case 4:
							salir = true;
							break;
						default:
							if(opcion < 1 && opcion > 4)
							System.out.println("Porfavor insertar numeros entre el 1 y 3");
							break;
					}
				break;
				
				case 2:
					System.out.println("� Que deseas modificar ?");
						System.out.println("Que deseas modificar?");
						System.out.println("1.- Modificar Sede de votaci�n");
						System.out.println("2.- Modificar votante");
						System.out.println("3.- Modificar vocal de mesa");
						System.out.println("4.- Presione 4 para salir");
						opcion1 = sn.nextInt();
					
					switch(opcion1) {
						case 1:
							System.out.println("Has seleccionado la opcion 1");
							break;
						case 2:
							System.out.println("Has seleccionado la opcion 2");
							break;
						case 3:
							System.out.println("Has seleccionado la opcion 3");
							break;
						case 4:
							salir = true;
							break;
						default:
							if(opcion1 < 1 && opcion1 > 4)
							System.out.println("Porfavor insertar numeros entre el 1 y 3");
							break;
					}
				break;
				
				case 3:
						System.out.println("� Que deseas eliminar ?");
						System.out.println("1.- Eliminar Sede de votaci�n");
						System.out.println("2.- Eliminar votante");
						System.out.println("3.- Eliminar vocal de mesa");
						System.out.println("4.- Presione 4 para salir");
						opcion2 = sn.nextInt();
					
					switch(opcion2) {
						case 1:
							System.out.println("Has seleccionado la opcion 1");
							break;
						case 2:
							System.out.println("Has seleccionado la opcion 2");
							break;
						case 3:
							System.out.println("Has seleccionado la opcion 3"); 
							break;
						case 4:
							salir = true;
							break;
						default:
							if(opcion2 < 1 && opcion2 > 4)
							System.out.println("Porfavor insertar numeros entre el 1 y 4");
					break;
					}
				break;
				
				case 4:
						System.out.println("� Que deseas buscar ?");
						System.out.println("1.- Buscar Sede de votaci�n");
						System.out.println("2.- Buscar votante");
						System.out.println("3.- Buscar vocal de mesa");
						System.out.println("4.- Presione 4 para salir");
						opcion3 = sn.nextInt();
					
					switch(opcion3) {
						case 1:
							System.out.println("Has seleccionado la opcion 1");
							break;
						case 2:
							System.out.println("Has seleccionado la opcion 2");
							break;
						case 3:
							System.out.println("Has seleccionado la opcion 3");
							break;
						case 4:
							salir = true;
							break;
						default:
							if(opcion3 < 1 && opcion3 > 4)
							System.out.println("Porfavor insertar numeros entre el 1 y 4");
							break;
					}
					default :
						if(opcion < 1 && opcion > 4)
						System.out.println("Porfavor insertar numeros entre el 1 y 4");
				}
			}catch (InputMismatchException e) {
				System.out.println("Debes insertar un numero");
				sn.next();
			}
		
		
		//Secci�n A�adir Sedes (NOMBRE/UBICACI�N/IDENTIFICADOR) --> SEDES CON PARAMETROS RESPECTIVOS PARA SER LLENADOS CON METODOS(VOTANTES-VOCALES)
		sufragio.a�adirSedes(new Sedes("Juan xxiii", "Villa Alemana", "2300 Personas"), null, null);
		sufragio.mostrarSedes();
		//Seccion Eliminar  Sedes
		sufragio.eliminarSedes("Nombre de la sede");
		
		//Seccion A�adir Votantes (NOMBRE/UBICACI�N/IDENTIFICADOR) --> VOTANTE POR LOCAL DE VOTACI�N 
		sufragio.a�adirVotante("Juan xxiii", new Votantes("asdsadasd","ahajas","23123-4"));
		//programar mostar Votantes
		sufragio.mostrarVotantes();
		
		//Seccion Eliminar Votantes
		sufragio.eliminarVotantes("Nombre del votante");
		
		//Seccion A�adir Vocal de mesa (NOMBRE/UBICACI�N/IDENTIFICADOR) --> VOCAL POR LOCAL DE VOTACI�N
		sufragio.a�adirVocal("Juan xxiii", new Vocal("HASJJHAS","HASJHJAS","20202032-3"));
		//programar mostrar Vocales
		sufragio.mostrarVocales();
		
		//Seccion Eliminar Vocal de mesa
		sufragio.eliminarVocales("Nombre del vocal de mesa");
		
	}

}
