package Ejecutable;

import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.ContainerAdapter;
import java.awt.event.ContainerEvent;
import java.awt.Font;

public class A�adirVotantes extends JDialog {

	private static final long serialVersionUID = 1L;
	private final JPanel contentPanel =new JPanel();
	private JTextField txtIdentificador;
	private JTextField txtNombre;
	private JTextField txtComuna;
	private JTextField txtMostrar;

	public static void main(String[] args) {
		try {
			A�adirVotantes dialog = new A�adirVotantes();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	//DIALOGOS
	public A�adirVotantes() {
		setTitle("A\u00F1adir Votantes");
		setBounds(100, 100, 545, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JLabel lblNewLabel = new JLabel("Nombre");
			lblNewLabel.setBounds(27, 26, 46, 14);
			contentPanel.add(lblNewLabel);
		}
		{
			JLabel lblNewLabel_1 = new JLabel("Identificador");
			lblNewLabel_1.setBounds(27, 50, 61, 14);
			contentPanel.add(lblNewLabel_1);
		}
		{
			JLabel lblNewLabel_2 = new JLabel("Comuna");
			lblNewLabel_2.setBounds(27, 75, 46, 14);
			contentPanel.add(lblNewLabel_2);
		}
		{
			txtIdentificador = new JTextField();
			txtIdentificador.addContainerListener(new ContainerAdapter() {
				@Override
				public void componentAdded(ContainerEvent arg0) {
					this.componentAdded(arg0); // A�ADIR IDENTIFICADOR RUT VOTANTE
				}
			});
			txtIdentificador.setBounds(102, 48, 165, 20);
			contentPanel.add(txtIdentificador);
			txtIdentificador.setColumns(10);
		}
		{
			txtNombre = new JTextField();
			txtNombre.addContainerListener(new ContainerAdapter() {
				@Override
				public void componentAdded(ContainerEvent arg0) {
					this.componentAdded(arg0); /// A�ADIR NOMBRE VOTANTE
				}
			});
			txtNombre.setBounds(102, 20, 165, 20);
			contentPanel.add(txtNombre);
			txtNombre.setColumns(10);
		}
		{
			txtComuna = new JTextField();
			txtComuna.addContainerListener(new ContainerAdapter() {
				@Override
				public void componentAdded(ContainerEvent arg0) {
					this.componentAdded(arg0); // A�ADIR COMUNA DE UBICACION VOTANTE
				}
			});
			txtComuna.setBounds(102, 76, 165, 20);
			contentPanel.add(txtComuna);
			txtComuna.setColumns(10);
		}
		{
			JButton btnNewButton = new JButton("Aceptar");
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					String ingreso = txtNombre.getText();
					String ingreso1 = txtIdentificador.getText();
					String ingreso2 = txtComuna.getText();
					
					txtMostrar.setText("Nombre : "+ingreso+"\n Identificador : "+ingreso1+"\n Comuna : "+ingreso2+"\n");
					
				}
			});
			btnNewButton.setBounds(415, 22, 89, 23);
			contentPanel.add(btnNewButton);
		}
		{
			JButton btnNewButton_1 = new JButton("Borrar");
			btnNewButton_1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					JTextField caja;
					for(int i=0 ; i< contentPanel.getComponentCount() ; i++) {
						if(contentPanel.getComponent(i).getClass().getName().equals("javax.swing.JTextField")) {
							caja= (JTextField)contentPanel.getComponent(i);
							caja.setText("");
						}
						
					}
				}
			});
			btnNewButton_1.setBounds(415, 46, 89, 23);
			contentPanel.add(btnNewButton_1);
		}
		{
			JButton btnNewButton_2 = new JButton("Cancelar");
			btnNewButton_2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					System.exit(0);
				}
			});
			btnNewButton_2.setBounds(415, 71, 89, 23);
			contentPanel.add(btnNewButton_2);
		}
		
		txtMostrar = new JTextField();
		txtMostrar.setFont(new Font("Times New Roman", Font.PLAIN, 11));
		txtMostrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
			}
		});
		txtMostrar.setBounds(27, 107, 492, 128);
		contentPanel.add(txtMostrar);
		txtMostrar.setColumns(10);
		{
			{
			}
		}
	}
}
