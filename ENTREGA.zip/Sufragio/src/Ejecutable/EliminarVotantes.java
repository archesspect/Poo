package Ejecutable;

import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class EliminarVotantes extends JDialog {

	
	private static final long serialVersionUID = 1L;
	private final JPanel contentPanel =new JPanel();
	private JTextField txtIdentificador;
	private JTextField txtNombre;
	private JTextField txtComuna;

	
	public static void main(String[] args) {
		try {
			EliminarVotantes dialog = new EliminarVotantes();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	//DIALOGO
	public EliminarVotantes() {
		setTitle("Eliminar Votantes");
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JLabel lblNewLabel = new JLabel("Nombre");
			lblNewLabel.setBounds(16, 21, 46, 14);
			contentPanel.add(lblNewLabel);
		}
		{
			JLabel lblNewLabel_1 = new JLabel("Identificador");
			lblNewLabel_1.setBounds(17, 51, 61, 14);
			contentPanel.add(lblNewLabel_1);
		}
		{
			JLabel lblNewLabel_2 = new JLabel("Comuna");
			lblNewLabel_2.setBounds(16, 78, 46, 14);
			contentPanel.add(lblNewLabel_2);
		}
		{
			txtIdentificador = new JTextField();
			txtIdentificador.setBounds(92, 48, 86, 20);
			contentPanel.add(txtIdentificador);
			txtIdentificador.setColumns(10);
		}
		{
			txtNombre = new JTextField();
			txtNombre.setBounds(93, 18, 86, 20);
			contentPanel.add(txtNombre);
			txtNombre.setColumns(10);
		}
		{
			txtComuna = new JTextField();
			txtComuna.setBounds(93, 78, 86, 20);
			contentPanel.add(txtComuna);
			txtComuna.setColumns(10);
		}
		{
			JButton btnNewButton = new JButton("Aceptar");
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
				}
			});
			btnNewButton.setBounds(296, 15, 89, 23);
			contentPanel.add(btnNewButton);
		}
		{
			JButton btnNewButton_1 = new JButton("Borrar");
			btnNewButton_1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
				}
			});
			btnNewButton_1.setBounds(296, 45, 89, 23);
			contentPanel.add(btnNewButton_1);
		}
		{
			JButton btnNewButton_2 = new JButton("Cancelar");
			btnNewButton_2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
				}
			});
			btnNewButton_2.setBounds(296, 74, 89, 23);
			contentPanel.add(btnNewButton_2);
		}
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(16, 107, 372, 124);
		contentPanel.add(scrollPane);
		
		JTextArea txtMostrar = new JTextArea();
		scrollPane.setViewportView(txtMostrar);
	}
}
