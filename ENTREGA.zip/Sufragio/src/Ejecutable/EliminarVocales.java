package Ejecutable;

import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class EliminarVocales extends JDialog {

	
	private static final long serialVersionUID = 1L;
	private final JPanel contentPanel =new JPanel();
	private JTextField txtIdentificador;
	private JTextField txtNombre;
	private JTextField txtComuna;

	
	public static void main(String[] args) {
		try {
			EliminarVocales dialog = new EliminarVocales();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	//DIALOGO
	public EliminarVocales() {
		setTitle("EliminarVocales");
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JLabel lblNewLabel = new JLabel("Nombre");
			lblNewLabel.setBounds(26, 25, 46, 14);
			contentPanel.add(lblNewLabel);
		}
		{
			JLabel lblIdentificador = new JLabel("Identificador");
			lblIdentificador.setBounds(25, 49, 61, 14);
			contentPanel.add(lblIdentificador);
		}
		{
			JLabel lblComuna = new JLabel("Comuna");
			lblComuna.setBounds(26, 78, 46, 14);
			contentPanel.add(lblComuna);
		}
		{
			txtIdentificador = new JTextField();
			txtIdentificador.setBounds(99, 46, 86, 20);
			contentPanel.add(txtIdentificador);
			txtIdentificador.setColumns(10);
		}
		{
			txtNombre = new JTextField();
			txtNombre.setBounds(99, 17, 86, 20);
			contentPanel.add(txtNombre);
			txtNombre.setColumns(10);
		}
		{
			txtComuna = new JTextField();
			txtComuna.setBounds(99, 75, 86, 20);
			contentPanel.add(txtComuna);
			txtComuna.setColumns(10);
		}
		{
			JButton btnNewButton = new JButton("Aceptar");
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
				}
			});
			btnNewButton.setBounds(287, 16, 89, 23);
			contentPanel.add(btnNewButton);
		}
		{
			JButton btnNewButton_1 = new JButton("Borrar");
			btnNewButton_1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
				}
			});
			btnNewButton_1.setBounds(288, 48, 89, 23);
			contentPanel.add(btnNewButton_1);
		}
		{
			JButton btnNewButton_2 = new JButton("Cancelar");
			btnNewButton_2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					System.exit(0);
				}
			});
			btnNewButton_2.setBounds(288, 78, 89, 23);
			contentPanel.add(btnNewButton_2);
		}
		{
			JScrollPane scrollPane = new JScrollPane();
			scrollPane.setBounds(25, 109, 363, 121);
			contentPanel.add(scrollPane);
			{
				JTextArea txtMostrar = new JTextArea();
				scrollPane.setViewportView(txtMostrar);
			}
		}
	}

}
