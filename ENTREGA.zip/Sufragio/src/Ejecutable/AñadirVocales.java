package Ejecutable;

import java.awt.BorderLayout;

import javax.swing.AbstractButton;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.ContainerAdapter;
import java.awt.event.ContainerEvent;
import java.awt.Font;


public class A�adirVocales extends JDialog {

	
	private static final long serialVersionUID = 1L;
	private final JPanel contentPanel =new JPanel();
	private JTextField txtIdentificador;
	private JTextField txtNombre;
	private JTextField txtComuna;
	protected AbstractButton txtMostrar;
	private JTextField textMostrar;

	
	public static void main(String[] args) {
		try {
			A�adirVocales dialog = new A�adirVocales();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	//DIALOGOS
	public A�adirVocales() {
		setTitle("A\u00F1adirVocales");
		setBounds(100, 100, 569, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JLabel lblNewLabel = new JLabel("Nombre");
			lblNewLabel.setBounds(24, 24, 37, 14);
			contentPanel.add(lblNewLabel);
		}
		{
			JLabel lblIdentificador = new JLabel("identificador");
			lblIdentificador.setBounds(22, 50, 59, 14);
			contentPanel.add(lblIdentificador);
		}
		{
			JLabel lblComuna = new JLabel("Comuna");
			lblComuna.setBounds(22, 76, 39, 14);
			contentPanel.add(lblComuna);
		}
		{
			txtIdentificador = new JTextField();
			txtIdentificador.addContainerListener(new ContainerAdapter() {
				@Override
				public void componentAdded(ContainerEvent e) {
					this.componentAdded(e);
				}
			});
			txtIdentificador.setBounds(94, 48, 151, 20);
			contentPanel.add(txtIdentificador);
			txtIdentificador.setColumns(10);
		}
		{
			txtNombre = new JTextField();
			txtNombre.addContainerListener(new ContainerAdapter() {
				@Override
				public void componentAdded(ContainerEvent arg0) {
					this.componentAdded(arg0);
				}
			});
			txtNombre.setColumns(10);
			txtNombre.setBounds(94, 21, 151, 20);
			contentPanel.add(txtNombre);
		}
		{
			txtComuna = new JTextField();
			txtComuna.addContainerListener(new ContainerAdapter() {
				@Override
				public void componentAdded(ContainerEvent e) {
					this.componentAdded(e);
				}
			});
			txtComuna.setColumns(10);
			txtComuna.setBounds(94, 74, 151, 20);
			contentPanel.add(txtComuna);
		}
		{
			JButton btnNewButton = new JButton("Aceptar");
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					String ingreso = txtNombre.getText();
					String ingreso1 = txtIdentificador.getText();
					String ingreso2 = txtComuna.getText();
					
					textMostrar.setText("Nombre : "+ingreso+"\n Identificador : "+ingreso1+"\n Comuna : "+ingreso2+"\n");
					
				}
			});
			btnNewButton.setBounds(396, 20, 89, 23);
			contentPanel.add(btnNewButton);
		}
		{
			JButton btnBorrar = new JButton("Borrar");
			btnBorrar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					JTextField caja;
					for(int i=0 ; i< contentPanel.getComponentCount() ; i++) {
						if(contentPanel.getComponent(i).getClass().getName().equals("javax.swing.JTextField")) {
							caja=(JTextField)contentPanel.getComponent(i);
							caja.setText("");
						}
					}	
				}
			});
			btnBorrar.setBounds(396, 46, 89, 23);
			contentPanel.add(btnBorrar);
		}
		{
			JButton btnCancelar = new JButton("Cancelar");
			btnCancelar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					System.exit(0);
				}
			});
			btnCancelar.setBounds(396, 72, 89, 23);
			contentPanel.add(btnCancelar);
		}
		{
			textMostrar = new JTextField();
			textMostrar.setFont(new Font("Times New Roman", Font.PLAIN, 11));
			textMostrar.setBounds(24, 101, 473, 149);
			contentPanel.add(textMostrar);
			textMostrar.setColumns(10);
		}
	}
}
