package colecciones;
import clases.Vocal;
import java.util.*;

public class ColeccionVocales {
	
	private ArrayList <Vocal> vocales;
	
	
	//MAP A�ADIR Y OBTENER VOCAL
	Map<String, Vocal> myMap = new HashMap<String, Vocal>();
	public void a�adirVocal(Vocal vocales) {
	    myMap.put(vocales.getNombreVocal(), vocales);
	}
	
	public Vocal obtenerVocal(Vocal vocales) {
		return myMap.get(vocales.getNombreVocal());
	}
	
	//Constructor
	public ColeccionVocales(){
		vocales = new ArrayList<>();
	}
	
	public boolean a�adirVocales (Vocal av ) {
		return vocales.add(av);
	}
	
	
	
	public boolean eliminarVocales(Vocal ev) {
		return vocales.remove(ev);
	}
	
	

}