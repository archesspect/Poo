package colecciones;
import clases.Sedes;
import clases.Vocal;
import clases.Votantes;

import java.util.*;

public class ColeccionSedes {
	
	private ArrayList <Sedes> sedes;
	private ArrayList <Votantes> votantes;
	private ArrayList <Vocal> vocales;
	
	//MAP A�ADIR Y OBTENER SEDE
	Map<String, Sedes> myMap = new HashMap<String, Sedes>();
	public void a�adirSede(Sedes s) {
	    myMap.put(s.getnombre(), s);
	}
	
	public Sedes obtenerSede(Sedes se) {
		return myMap.get(se.getnombre());
	}
	
	
	//Constructor
	public ColeccionSedes(){
		sedes = new ArrayList<>();
		votantes = new ArrayList<>();
		vocales = new ArrayList<>();
	}
	
	//metodo
	public boolean a�adirSedes (Sedes a�adirSede ) {
		return sedes.add(a�adirSede);
	}
	
	public void mostrarSedes() {
		sedes.forEach((a�adirSede) -> {
			String nombreSede = a�adirSede.getnombre();
			System.out.println("Nombre Sede : "+nombreSede);
		});
		
		sedes.forEach((a�adirSede) -> {
			String ubicacionSede = a�adirSede.getubicacion();
			System.out.println("Ubicaci�n Sede : "+ubicacionSede);
		});
		
		sedes.forEach((a�adirSede) -> {
			String capacidadSede = a�adirSede.getcapacidadLocal();
			System.out.println("Capacidad Sede : "+capacidadSede);
		});
	}
	
	public boolean eliminarSede(String eliminarSede) {
		return false;
	}

	public boolean a�adirVotante(String nombreSede, Votantes votante) {
		for (Sedes sede : sedes) {
			if(sede.getnombre().equals(nombreSede)) {
				return sede.agregarVotante(votante);
			}
		}
		return false;
	}
	
	public void mostrarVotantes() {
		votantes.forEach((votante) -> {
			String nombreVotante = votante.getnombreVotante();
			System.out.println("Nombre Votante : "+nombreVotante);
		});
		
		vocales.forEach((votante) -> {
			String ubicacionVotante = votante.ubicacionVotante();
			System.out.println("Ubicaci�n Votante : "+ubicacionVotante);
		});
		
		vocales.forEach((votante) -> {
			String identificadorVotante = votante.getIdentificadorVocal();
			System.out.println("Rut Vocal de mesa : "+identificadorVotante);
		});
	}
	
	public boolean eliminarVotantes(String eliminarVotante) {
		return false;
	}
	
	public boolean a�adirVocales(String nombreSede, Vocal vocal) {
		for (Sedes sede : sedes) {
			if(sede.getnombre().equals(nombreSede)) {
				return sede.a�adirVocales(vocal);
			}
		}
		return false;
	}
	
	public void mostrarVocales() {
		vocales.forEach((a�adirVocal) -> {
			String nombreVocal = a�adirVocal.getNombreVocal();
			System.out.println("Nombre Vocal de mesa : "+nombreVocal);
		});
		
		vocales.forEach((a�adirVocal) -> {
			String ubicacionVocal = a�adirVocal.getUbicacionVocal();
			System.out.println("Ubicaci�n Vocal de mesa : "+ubicacionVocal);
		});
		
		vocales.forEach((a�adirVocal) -> {
			String identificadorVocal = a�adirVocal.getIdentificadorVocal();
			System.out.println("Rut Vocal de mesa : "+identificadorVocal);
		});
	}
	
	public boolean eliminarVocales(String eliminarvocal) {
		return false;
	}

	

	
	
		

}
