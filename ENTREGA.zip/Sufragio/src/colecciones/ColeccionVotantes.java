package colecciones;
import clases.Votantes;
import java.util.*;

public class ColeccionVotantes {
	
	private ArrayList <Votantes> votantes;
	
	//MAP A�ADIR Y OBTENER VOTANTE
		Map<String, Votantes> myMap = new HashMap<String, Votantes>();
		public void a�adirVotante(Votantes votantes) {
		    myMap.put(votantes.getnombreVotante(), votantes);
		}
		
		public Votantes obtenerVotante(Votantes votantes) {
			return myMap.get(votantes.getnombreVotante());
		}
		
	
	public ColeccionVotantes() {
		votantes = new ArrayList<>();
	}
	
	public boolean a�adirVotantes(Votantes v) {
		return votantes.add(v);
	}
	
	public void mostrarVotantes(Object object) {
		mostrarVotantes(object);
	}
		
	
	public boolean eliminarVotantes(Votantes ev) {
		return votantes.remove(ev);
	}
	
}
