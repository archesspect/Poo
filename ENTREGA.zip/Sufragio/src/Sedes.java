public class Sedes {

    private Object untitledField;
}
